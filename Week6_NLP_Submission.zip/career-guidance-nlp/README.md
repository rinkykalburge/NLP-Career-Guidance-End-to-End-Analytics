# Student Career Guidance Assistant - End-to-End NLP Analytics (Week 6)

Integrated prototype: preprocessing -> intent classification -> NER -> topic modeling (LDA) -> summarisation (TextRank).

## Run
    pip install -r requirements.txt
    python career_pipeline.py

Outputs `results.json` (all numbers quoted in the report) and four figures.

## Note on data
The 160-query corpus is partly template-generated and the NER / summarisation test sets are small and hand-made.
Scores demonstrate the evaluation method; they are not benchmark results. See Section 12 of the report.
