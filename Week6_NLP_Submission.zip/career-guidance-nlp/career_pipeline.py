"""
Student Career Guidance Assistant - end-to-end NLP prototype (Week 6)
Stages: preprocessing -> intent classification -> NER -> topic modeling -> summarization
Run:  python career_pipeline.py     (needs scikit-learn, numpy, matplotlib)
Everything is deterministic (random_state=42). Results are written to results.json.
NOTE: the corpus is a small synthetic/hand-written prototype corpus, not a public benchmark.
"""
import re, json, random, itertools
from collections import Counter
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer, ENGLISH_STOP_WORDS
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.pipeline import make_pipeline
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

random.seed(42); np.random.seed(42)
R = {}

# ------------------------------------------------------------------ 1. CORPUS
skills = ["Python", "Java", "machine learning", "data structures", "SQL", "web development",
          "cloud computing", "embedded systems", "cyber security", "data analysis"]
orgs   = ["TCS", "Infosys", "Wipro", "Bosch", "Amazon", "Flipkart"]
cities = ["Bengaluru", "Hyderabad", "Pune", "Kalaburagi", "Chennai"]
exams  = ["GATE", "GRE", "CAT", "KCET"]
roles  = ["data analyst", "software developer", "network engineer", "business analyst", "ML engineer"]

T = {
 "course": [
   "Which course should I take to learn {s}?", "Suggest a good online course for {s} for beginners",
   "I want to start learning {s}, where do I begin?", "Is there a certification in {s} worth doing in my third year?",
   "Recommend a roadmap to study {s} in six months", "Best free resources to learn {s} for a CSE student"],
 "role": [
   "What does a {r} do every day?", "What is the average salary of a {r} in {c}?",
   "Tell me about the career path of a {r}", "Is {r} a good career for a fresher from a tier 3 college?",
   "What qualifications do I need to become a {r}?", "How is the job market for a {r} in {c}?"],
 "skillgap": [
   "I know {s} but not {s2}, what should I improve to become a {r}?", "What skills am I missing to get hired as a {r}?",
   "My resume only lists {s}, is that enough for a {r} job?", "How can I fill my skill gap in {s2} before placements?",
   "Which skills do recruiters at {o} expect from a {r}?", "I am weak in {s}, how do I get job ready?"],
 "intern": [
   "How can I get an internship at {o}?", "Are there any summer internships in {c} for {s}?",
   "When does {o} open internship applications?", "Can a second year student apply for an internship in {s}?",
   "Looking for a remote internship in {s}", "What should I put in my resume to get an internship at {o}?"],
 "higher": [
   "Should I write {e} to do my masters?", "How should I prepare for {e} while studying {s}?",
   "Which universities accept a {e} score for MS in {s}?", "Is MBA through {e} better than a job at {o}?",
   "When is the {e} exam and how many months of preparation do I need?", "Is it better to do M.Tech after B.E. or join {o}?"],
}
rows = []
for intent, tmpls in T.items():
    for t in tmpls:
        for _ in range(5):
            s, s2 = random.sample(skills, 2)
            q = t.format(s=s, s2=s2, o=random.choice(orgs), c=random.choice(cities),
                         e=random.choice(exams), r=random.choice(roles))
            rows.append((q, intent))
# 10 deliberately ambiguous / cross-intent queries (realistic noise)
amb = [("Should I learn Python or prepare for GATE this year?", "higher"),
       ("Which course helps me get an internship at Amazon?", "intern"),
       ("Is data analysis a good career and which course should I do?", "role"),
       ("Do I need GATE to become a software developer?", "role"),
       ("What skills does Bosch want for embedded systems internships?", "skillgap"),
       ("Course for GRE or for cloud computing, confused", "higher"),
       ("Resume tips for a data analyst internship in Pune", "intern"),
       ("Will learning SQL help me get a job at Infosys?", "skillgap"),
       ("How to learn machine learning for a masters application?", "higher"),
       ("Suggest courses to become a business analyst", "course")]
rows += amb
random.shuffle(rows)
X_raw = [r[0] for r in rows]; y = np.array([r[1] for r in rows])
R["corpus_size"] = len(rows); R["class_counts"] = dict(Counter(y))
R["n_unique_queries"] = len(set(X_raw))

# ------------------------------------------------------------------ 2. PREPROCESSING
KEEP = {"not", "no", "before", "after", "how", "when", "which", "what"}   # negation / wh-words carry intent
STOP = set(ENGLISH_STOP_WORDS) - KEEP
def light_stem(w):
    for suf in ("ing", "ies", "ed", "es", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 4:
            return w[: -len(suf)] + ("y" if suf == "ies" else "")
    return w
def preprocess(text):
    t = text.lower()
    t = re.sub(r"[^a-z0-9\s\.\+#]", " ", t)
    toks = [x.strip(".") for x in t.split()]
    toks = [light_stem(w) for w in toks if w and w not in STOP]
    return " ".join(toks)

example = "Which skills do recruiters at Infosys expect from a data analyst?"
R["preprocess_example"] = {"raw": example, "clean": preprocess(example)}
raw_vocab = len(set(w for q in X_raw for w in re.findall(r"[a-z0-9]+", q.lower())))
X = [preprocess(q) for q in X_raw]
clean_vocab = len(set(w for q in X for w in q.split()))
R["vocab_before"], R["vocab_after"] = raw_vocab, clean_vocab

# ------------------------------------------------------------------ 3. CLASSIFICATION
skf = StratifiedKFold(5, shuffle=True, random_state=42)
models = {
 "NaiveBayes + BoW":      make_pipeline(CountVectorizer(), MultinomialNB()),
 "LogReg + TF-IDF(1,1)":  make_pipeline(TfidfVectorizer(), LogisticRegression(max_iter=1000)),
 "LogReg + TF-IDF(1,2)":  make_pipeline(TfidfVectorizer(ngram_range=(1, 2)), LogisticRegression(max_iter=1000)),
 "LinearSVM + TF-IDF(1,2)": make_pipeline(TfidfVectorizer(ngram_range=(1, 2)), LinearSVC()),
}
R["classification"] = {}; preds = {}
for name, m in models.items():
    p = cross_val_predict(m, X, y, cv=skf); preds[name] = p
    pr, rc, f1, _ = precision_recall_fscore_support(y, p, average="macro", zero_division=0)
    R["classification"][name] = dict(acc=accuracy_score(y, p), prec=pr, rec=rc, f1=f1)
best = max(R["classification"], key=lambda k: R["classification"][k]["f1"])
R["best_model"] = best
labels = sorted(set(y))
cm = confusion_matrix(y, preds[best], labels=labels)
R["confusion"] = {"labels": labels, "matrix": cm.tolist()}
pr, rc, f1, sup = precision_recall_fscore_support(y, preds[best], labels=labels, zero_division=0)
R["per_class"] = {l: dict(p=float(a), r=float(b), f=float(c), n=int(d)) for l, a, b, c, d in zip(labels, pr, rc, f1, sup)}
# misclassified examples
wrong = [(X_raw[i], y[i], preds[best][i]) for i in range(len(y)) if y[i] != preds[best][i]]
R["n_errors"] = len(wrong); R["error_examples"] = wrong[:8]
# top features of final LR model
lr = make_pipeline(TfidfVectorizer(ngram_range=(1, 2)), LogisticRegression(max_iter=1000)).fit(X, y)
vec, clf = lr.steps[0][1], lr.steps[1][1]
fn = np.array(vec.get_feature_names_out())
R["top_features"] = {c: fn[np.argsort(clf.coef_[i])[-5:][::-1]].tolist() for i, c in enumerate(clf.classes_)}
# ablation: no preprocessing
m_raw = make_pipeline(TfidfVectorizer(ngram_range=(1, 2)), LogisticRegression(max_iter=1000))
p_raw = cross_val_predict(m_raw, X_raw, y, cv=skf)
R["ablation_raw_f1"] = precision_recall_fscore_support(y, p_raw, average="macro", zero_division=0)[2]

# ------------------------------------------------------------------ 4. NER (gazetteer + rules) on HAND-ANNOTATED held-out set
GAZ = {
 "SKILL": ["python", "java", "machine learning", "data structures", "sql", "web development", "cloud computing",
           "embedded systems", "cyber security", "data analysis", "deep learning", "excel"],
 "ORG":   ["tcs", "infosys", "wipro", "bosch", "amazon", "flipkart", "google"],
 "LOC":   ["bengaluru", "hyderabad", "pune", "kalaburagi", "chennai", "mumbai"],
 "EXAM":  ["gate", "gre", "cat", "kcet", "ielts"],
 "ROLE":  ["data analyst", "software developer", "network engineer", "business analyst", "ml engineer", "data scientist"],
}
ALIASES = {"ML": "SKILL", "AI": "SKILL"}   # tiny alias list added AFTER error analysis (see report)
test = [  # (sentence, [(span, label)])  -- hand annotated, includes out-of-gazetteer forms
 ("I am a BKIT Bhalki student interested in machine learning and want an internship at Google in Bengaluru.",
  [("BKIT Bhalki", "ORG"), ("machine learning", "SKILL"), ("Google", "ORG"), ("Bengaluru", "LOC")]),
 ("Should I prepare for GATE or apply for a data analyst job at Wipro?",
  [("GATE", "EXAM"), ("data analyst", "ROLE"), ("Wipro", "ORG")]),
 ("I know Python and SQL but lack deep learning for a data scientist role.",
  [("Python", "SKILL"), ("SQL", "SKILL"), ("deep learning", "SKILL"), ("data scientist", "ROLE")]),
 ("Is Infy hiring freshers in Hyderabad this year?", [("Infy", "ORG"), ("Hyderabad", "LOC")]),
 ("I scored 310 in GRE and want to study ML in Germany.",
  [("GRE", "EXAM"), ("ML", "SKILL"), ("Germany", "LOC")]),
 ("Bosch is offering an embedded systems internship in Pune.",
  [("Bosch", "ORG"), ("embedded systems", "SKILL"), ("Pune", "LOC")]),
 ("Can I become a software developer without cat or gate?", [("software developer", "ROLE"), ("gate", "EXAM")]),
 ("Amazon asked about data structures in the Chennai interview.",
  [("Amazon", "ORG"), ("data structures", "SKILL"), ("Chennai", "LOC")]),
 ("Which is better, cloud computing or cyber security, for a network engineer?",
  [("cloud computing", "SKILL"), ("cyber security", "SKILL"), ("network engineer", "ROLE")]),
 ("I want to learn Excel and Power BI before applying to Flipkart.",
  [("Excel", "SKILL"), ("Power BI", "SKILL"), ("Flipkart", "ORG")]),
 ("IELTS or GRE for MS in the USA?", [("IELTS", "EXAM"), ("GRE", "EXAM"), ("USA", "LOC")]),
 ("TCS Ninja test preparation for a fresher from Kalaburagi.", [("TCS", "ORG"), ("Kalaburagi", "LOC")]),
]
def tag(sentence, use_alias=False, use_rules=False):
    found = []; low = sentence.lower()
    for lab, items in GAZ.items():
        for it in sorted(items, key=len, reverse=True):
            for m in re.finditer(r"\b" + re.escape(it) + r"\b", low):
                found.append((m.start(), m.end(), lab))
    if use_alias:
        for a, lab in ALIASES.items():
            for m in re.finditer(r"\b" + a + r"\b", sentence):
                found.append((m.start(), m.end(), lab))
    if use_rules:   # capitalised token(s) after in/at/to/for/from -> ORG/LOC unknown; here: 'in|at' + Capitalised -> LOC
        for m in re.finditer(r"\b(?:in|to)\s+((?:the\s+)?[A-Z][a-zA-Z]+)", sentence):
            found.append((m.start(1), m.end(1), "LOC"))
        for m in re.finditer(r"\b(?:at|to)\s+([A-Z][a-zA-Z]+)", sentence):
            found.append((m.start(1), m.end(1), "ORG"))
    # resolve overlaps: keep longest
    found.sort(key=lambda x: (x[0], -(x[1] - x[0]))); out = []; last = -1
    for s, e, l in found:
        if s >= last: out.append((sentence[s:e], l)); last = e
    return out
def ner_eval(**kw):
    tp = fp = fn_ = 0; per = {}
    for sent, gold in test:
        pred = set((p[0].lower(), p[1]) for p in tag(sent, **kw)); g = set((a.lower(), b) for a, b in gold)
        tp += len(pred & g); fp += len(pred - g); fn_ += len(g - pred)
    P = tp / (tp + fp) if tp + fp else 0; Rr = tp / (tp + fn_) if tp + fn_ else 0
    F = 2 * P * Rr / (P + Rr) if P + Rr else 0
    return dict(tp=tp, fp=fp, fn=fn_, p=P, r=Rr, f=F)
R["ner_n_sentences"] = len(test); R["ner_n_gold"] = sum(len(g) for _, g in test)
R["ner_v1_gazetteer"] = ner_eval()
R["ner_v2_alias"] = ner_eval(use_alias=True)
R["ner_v3_alias_rules"] = ner_eval(use_alias=True, use_rules=True)
# error listing for v1
errs = []
for sent, gold in test:
    pred = set((p[0].lower(), p[1]) for p in tag(sent)); g = set((a.lower(), b) for a, b in gold)
    for a, b in sorted(g - pred): errs.append(("MISSED", a, b))
    for a, b in sorted(pred - g): errs.append(("SPURIOUS", a, b))
R["ner_v1_errors"] = errs

# ------------------------------------------------------------------ 5. TOPIC MODELING (LDA)
cv = CountVectorizer(min_df=2, max_df=0.6); Xc = cv.fit_transform(X)
vocab = np.array(cv.get_feature_names_out()); Xb = (Xc > 0).astype(int).toarray()
def umass(top_idx):
    s = 0; n = 0
    for i in range(1, len(top_idx)):
        for j in range(i):
            wi, wj = top_idx[i], top_idx[j]
            d_j = Xb[:, wj].sum(); co = (Xb[:, wi] * Xb[:, wj]).sum()
            s += np.log((co + 1) / d_j); n += 1
    return s / n
R["lda"] = {}
models_lda = {}
for k in range(3, 9):
    lda = LatentDirichletAllocation(n_components=k, random_state=42, learning_method="batch", max_iter=60).fit(Xc)
    tops = [np.argsort(c)[-8:][::-1] for c in lda.components_]
    R["lda"][k] = dict(perplexity=float(lda.perplexity(Xc)), umass=float(np.mean([umass(t) for t in tops])))
    models_lda[k] = (lda, tops)
bestk = max(R["lda"], key=lambda k: R["lda"][k]["umass"]); R["lda_best_k"] = bestk
K5 = 5
lda5, tops5 = models_lda[K5]
R["lda_k5_topics"] = [vocab[t][:7].tolist() for t in tops5]
# dominant topic vs intent purity
dom = lda5.transform(Xc).argmax(1)
R["lda_purity"] = float(sum(Counter(y[dom == t]).most_common(1)[0][1] for t in range(K5) if (dom == t).any()) / len(y))

# ------------------------------------------------------------------ 6. SUMMARIZATION (TextRank vs Lead-3) + ROUGE
docs = [
 {"text": ("Rahul is a third year computer science student who met the placement counsellor on Monday. "
           "He said he enjoys programming but is unsure whether to prepare for campus placements or for GATE. "
           "The counsellor reviewed his marks, which average seventy two percent, and his two mini projects in Python. "
           "She advised him that placements in service companies usually need strong aptitude and basic data structures. "
           "She added that GATE preparation needs at least eight months of focused study on core subjects. "
           "Rahul mentioned that his family prefers a job after graduation because of financial pressure. "
           "The counsellor suggested he continue placement preparation now and keep GATE as a backup for next year. "
           "They agreed to meet again in December to review his progress on aptitude tests."),
  "ref": "Rahul, a third year CS student, is unsure between placements and GATE. The counsellor advised him to continue placement preparation focused on aptitude and data structures and keep GATE as a backup, and they will review progress in December."},
 {"text": ("A new internship programme was announced by the training and placement cell for pre-final year students. "
           "Applications will open on fifteenth November and close on thirtieth November. "
           "Students must have no active backlogs and a minimum aggregate of sixty percent. "
           "The programme offers eight week internships in data analysis, web development and embedded systems. "
           "Selected students will be shortlisted through an online aptitude test followed by a short interview. "
           "Partner companies include several firms in Bengaluru and Pune. "
           "Students are encouraged to update their resumes and add project links before applying. "
           "Certificates will be issued only after the completion of a final presentation."),
  "ref": "The placement cell opens applications from 15 to 30 November for eight week internships in data analysis, web development and embedded systems for pre-final year students with no backlogs and sixty percent marks, selected through an aptitude test and interview."},
 {"text": ("Many engineering graduates struggle to decide between higher studies and jobs. "
           "A common concern is that entrance exams like GATE and GRE need long preparation while jobs offer immediate income. "
           "Advisors recommend comparing salary growth, research interest and the cost of study before deciding. "
           "Students from smaller towns often lack access to mentors who can explain these trade-offs. "
           "Online platforms provide information but rarely personalise it to the student's marks and skills. "
           "A conversational assistant that understands the student's question and profile can reduce this gap. "
           "Such an assistant should always direct students to a human counsellor for final decisions."),
  "ref": "Graduates struggle to choose between higher studies and jobs, and students from small towns lack mentors; a conversational assistant that personalises advice could reduce this gap while still directing students to human counsellors."},
]
def toks(s): return re.findall(r"[a-z0-9]+", s.lower())
def ngrams(t, n): return Counter(tuple(t[i:i + n]) for i in range(len(t) - n + 1))
def rouge(c, r, n):
    cn, rn = ngrams(toks(c), n), ngrams(toks(r), n); ov = sum((cn & rn).values())
    p = ov / max(sum(cn.values()), 1); rc = ov / max(sum(rn.values()), 1)
    return (2 * p * rc / (p + rc)) if p + rc else 0
def split_sents(t): return [s.strip() for s in re.split(r"(?<=[a-z])\.\s+", t.strip().rstrip(".") + ".") if s.strip()]
def textrank(text, k=3, d=0.85):
    sents = split_sents(text); v = TfidfVectorizer(stop_words="english").fit_transform(sents)
    S = (v @ v.T).toarray(); np.fill_diagonal(S, 0)
    rs = S.sum(1, keepdims=True); rs[rs == 0] = 1; P = S / rs
    sc = np.ones(len(sents)) / len(sents)
    for _ in range(100): sc = (1 - d) / len(sents) + d * P.T @ sc
    idx = sorted(np.argsort(sc)[-k:]); return " ".join(sents[i].rstrip(".") + "." for i in idx), [int(i) + 1 for i in idx]
def lead(text, k=3): return " ".join(s.rstrip(".") + "." for s in split_sents(text)[:k])
R["summ"] = []
for i, dct in enumerate(docs):
    tr, picked = textrank(dct["text"]); ld = lead(dct["text"])
    R["summ"].append(dict(doc=i + 1, n_sents=len(split_sents(dct["text"])), n_words=len(toks(dct["text"])),
        picked=picked, textrank=tr, lead3=ld,
        tr_r1=rouge(tr, dct["ref"], 1), tr_r2=rouge(tr, dct["ref"], 2),
        ld_r1=rouge(ld, dct["ref"], 1), ld_r2=rouge(ld, dct["ref"], 2),
        tr_words=len(toks(tr)), ref_words=len(toks(dct["ref"]))))
R["summ_avg"] = {k: float(np.mean([s[k] for s in R["summ"]])) for k in ["tr_r1", "tr_r2", "ld_r1", "ld_r2"]}

# ------------------------------------------------------------------ 7. FIGURES
plt.rcParams.update({"font.size": 10, "font.family": "DejaVu Sans"})
fig, ax = plt.subplots(figsize=(5.2, 4.4))
ax.imshow(cm, cmap="Blues")
ax.set_xticks(range(5)); ax.set_yticks(range(5)); ax.set_xticklabels(labels, rotation=35, ha="right"); ax.set_yticklabels(labels)
for i in range(5):
    for j in range(5): ax.text(j, i, cm[i, j], ha="center", va="center", color="white" if cm[i, j] > cm.max() / 2 else "black")
ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title(f"Confusion matrix: {best}\n(5-fold CV, n={len(y)})", fontsize=10)
plt.tight_layout(); plt.savefig("fig_confusion.png", dpi=170); plt.close()

fig, ax = plt.subplots(figsize=(6.4, 3.4))
names = list(R["classification"]); f1s = [R["classification"][n]["f1"] for n in names]
bars = ax.barh(names, f1s, color=["#9db4d3", "#6f95c4", "#3b6ea8", "#1f4e86"])
for b, v in zip(bars, f1s): ax.text(v + 0.005, b.get_y() + b.get_height() / 2, f"{v:.3f}", va="center")
ax.set_xlim(min(f1s) - 0.08, 1.02); ax.set_xlabel("Macro-F1 (5-fold CV)"); ax.set_title("Intent classification: model comparison", fontsize=10)
plt.tight_layout(); plt.savefig("fig_models.png", dpi=170); plt.close()

ks = sorted(R["lda"]); fig, ax1 = plt.subplots(figsize=(6, 3.3))
ax1.plot(ks, [R["lda"][k]["umass"] for k in ks], "o-", color="#1f4e86"); ax1.set_xlabel("Number of topics (k)"); ax1.set_ylabel("UMass coherence (higher is better)", color="#1f4e86")
ax2 = ax1.twinx(); ax2.plot(ks, [R["lda"][k]["perplexity"] for k in ks], "s--", color="#b5532a"); ax2.set_ylabel("Perplexity (lower is better)", color="#b5532a")
ax1.set_title("LDA: choosing k", fontsize=10); plt.tight_layout(); plt.savefig("fig_lda.png", dpi=170); plt.close()

# pipeline diagram
fig, ax = plt.subplots(figsize=(7.2, 4.6)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 6.4)
def box(x, y_, w, h, t, c):
    ax.add_patch(plt.Rectangle((x, y_), w, h, fc=c, ec="#1f3b5c", lw=1.2, zorder=2)); ax.text(x + w / 2, y_ + h / 2, t, ha="center", va="center", fontsize=8.3, zorder=3)
def arr(x1, y1, x2, y2): ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="->", color="#1f3b5c", lw=1.3), zorder=1)
box(3.2, 5.3, 3.6, 0.8, "Student query / counsellor notes\n(raw text)", "#eef3f9")
box(3.2, 4.1, 3.6, 0.8, "Preprocessing (Week 2)\nclean, tokenise, stop-words, stem", "#d7e5f3")
box(0.2, 2.6, 2.9, 0.95, "Intent classifier (Week 3)\nTF-IDF(1,2) + LogReg or SVM", "#c3d9ee")
box(3.55, 2.6, 2.9, 0.95, "NER (Week 4)\ngazetteer + alias + rules", "#c3d9ee")
box(6.9, 2.6, 2.9, 0.95, "Topic model (Week 5)\nLDA, k=5", "#c3d9ee")
box(0.2, 1.1, 4.5, 0.95, "Response planner\nintent + entities + profile -> answer template", "#f6e3c6")
box(5.3, 1.1, 4.5, 0.95, "Summariser (Week 5)\nTextRank for counsellor notes / long pages", "#f6e3c6")
box(2.6, 0.05, 4.8, 0.7, "Reply to student + analytics dashboard (topic trends)", "#dcefd9")
arr(5, 5.3, 5, 4.9); arr(4.6, 4.1, 1.7, 3.55); arr(5, 4.1, 5, 3.55); arr(5.4, 4.1, 8.3, 3.55)
arr(1.7, 2.6, 2.2, 2.05); arr(5, 2.6, 3.5, 2.05); arr(8.3, 2.6, 7.5, 2.05); arr(2.5, 1.1, 4.2, 0.75); arr(7.5, 1.1, 5.8, 0.75)
plt.tight_layout(); plt.savefig("fig_pipeline.png", dpi=170); plt.close()

json.dump(R, open("results.json", "w"), indent=1, default=str)
print(json.dumps({k: R[k] for k in ["corpus_size","class_counts","vocab_before","vocab_after","classification","best_model","n_errors","ablation_raw_f1","ner_v1_gazetteer","ner_v2_alias","ner_v3_alias_rules","lda_best_k","lda_purity","summ_avg"]}, indent=1, default=str))
